<?php require("header-inc.php"); ?>

<div class="container">
    <div class="jumbotron">
    <h1 class="display-4">Olá, Fatecanos!</h1>
    <p class="lead">Esse é um exemplo de CRUD de uma tabela utilizando PHP & MySQL.</p>
    <hr class="my-4">
    <p>Exercício em sala de aula para o 3º termo do curso de Análise e Desenvolvimento de Sistemas</p>
    <p></p>
    <img src="images/img-fatecpp.jpg" class="img-fluid" alt="Responsive image">
    <p></p>
    <a class="btn btn-primary btn-lg" href="https://fatecpp.edu.br/curso/analise-e-desenvolvimento-de-sistemas/" target="_blank" role="button">Veja mais</a>
    </div>
</div>

<?php require("footer-inc.php"); ?>