<p> </p>
<footer class="text-center text-white fixed-bottom " style="background-color: slategrey " >
    <p> </p>
   
    <p>Copyright  © FATEC Presidente Prudente <?= date('Y'); ?> · <a class="text-white" href="#">Privacidade de Dados</a> · <a class="text-white" href="#">Termos de Uso</a></p>
    <p> </p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
</body>
</html>