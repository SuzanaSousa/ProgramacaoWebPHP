<?php require_once "header.php"; ?>

<div class="container">
    <br />
    <h3 class= "text-center">Tela Principal</h3>
    <br />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <div class="text-center" >
        <button type="button  " class="  btn btn-primary bg-warning dropdown-toggle" data-bs-toggle="dropdown">
        Quetões
        </button>
    <div>
    <ul class=" text-center dropdown-menu">
      
      <li><a class="dropdown-item " href="/Exercicio03Suzana/Exercicio01.php">01</a></li>
      
      <li><a class="dropdown-item " href="/Exercicio03Suzana/Exercicio02.php">02</a></li>

      <li><a class="dropdown-item " href="/Exercicio03Suzana/Exercicio03.php">03</a></li>
    </ul>
</div>

<?php require_once "footer.php"; ?>