<!DOCTYPE html>
<html lang="en">
  <head>
      <title></title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      <style> 
        #borderimg { 
          border: 10px solid transparent;
          padding: 15px;
          border-image-source: url(logo.png);  
          border-image-slice: 30;
        }
      </style>

     
  </head>
  <body class="bg-secondary text-white ">
    
    <div class="container .text-center">
      <h1 class="text-center display-2">Eletiva Linguagem de Programação IV</h1>
      <p  class="text-center">Click no botão para ter acesso as questão.</p>
      <nav class="text-center" >
        <button  type="button" class="btn btn-warning"  data-toggle="collapse" 
        data-target="#demo">Atividades</button>
        
      </nav>
      <div id="demo" class=" collapse" tabindex="-1" >
        <h2> 
          <a href ="/Exercicio/Projeto/Primeiro.php">
             <button type="button" class="d-flex btn btn-warning ">Questão 01</button>
          </a>
          <a href ="/Exercicio/Projeto/Segundo.php">
              <button type="button" class="d-flex btn btn-warning">Questão 02</button>
          </a>
              <button type="button" class="d-flex btn btn-warning">Questão 03</button>
              <button type="button" class="d-flex btn btn-warning">Questão 04</button>
              <button type="button" class="d-flex btn btn-warning">Questão 05</button>
              <button type="button" class="d-flex btn btn-warning">Questão 06</button>
              <button type="button" class="d-flex btn btn-warning">Questão 07</button>
              <button type="button" class="d-flex btn btn-warning">Questão 08</button>
              <button type="button" class="d-flex btn btn-warning">Questão 09</button>
              <button type="button" class="d-flex btn btn-warning">Questão 10</button>
              <button type="button" class="d-flex btn btn-warning">Questão 11</button>
              <button type="button" class="d-flex btn btn-warning">Questão 12</button>
              <button type="button" class="d-flex btn btn-warning">Questão 13</button>
            
        </h2>

      </div>
      
       
      

    </div>

  </body>
</html>